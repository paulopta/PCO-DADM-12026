import { useState, useEffect } from 'react';
import { View, Text, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';

import Splash from './src/screens/splash_screen';
import Personagens from './src/screens/personagens';
import Sobre from './src/screens/sobre';

const Drawer = createDrawerNavigator();

export default function App() {

  const [carregando, setCarregando] = useState(true);

  useEffect(() => {

    setTimeout(() => {
      setCarregando(false);
    }, 3000);

  }, []);

  if (carregando) {
    return (
      <Splash />
    );
  }

  return (
    <NavigationContainer>
      <Drawer.Navigator>
        <Drawer.Screen
          name="Personagens"
          component={Personagens}
        />
        <Drawer.Screen
          name="Sobre"
          component={Sobre}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}