import {View, Text, ImageBackground, StyleSheet} from 'react-native';

const Splash_screen = () => {

 const imageSource = require('../img/mk_snes_title.png');

  return(

    <ImageBackground
      source={imageSource}
      style={styles.background} // Apply style to the container
      // resizeMode="cover" is the default, but you can explicitly set it
      resizeMode="stretch" 
    >

    <View style={styles.contentContainer} >
        <Text style={styles.text} >Lista de Golpes</Text>
    </View>
    </ImageBackground>
  );

}

const styles = StyleSheet.create({
  background: {
    flex: 1, // This makes the ImageBackground component fill the entire screen
    justifyContent: 'center', // Centers children vertically
    alignItems: 'center', // Centers children horizontally
  },
  contentContainer: {
    // Styles for the view overlaying the image
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent overlay for readability
    borderRadius: 10,
    marginTop: 300
  },
  text: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center'
  },
});

export default Splash_screen;