import {View, Text, Image, StyleSheet} from 'react-native'

const Sobre = () => {

  return(
    <View style={styles.container}>
      <Image 
        source={require('../img/mortal_kombat_logo.png')}
        style= {styles.logo}
      />
      <Text style={styles.titulo2}>Aplicativo desenvolvido na Disciplina de Desenvolvimento de Aplicações Móveis 
      e Distribuídas da PUC MINAS - 2026</Text>
      <Text style={styles.titulo2}>Professor - Paulo Henrique Rodrigues</Text>
    </View>);

}

const styles= StyleSheet.create({
  container:{
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffffff"
  },
  titulo2: {
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 10
  },
  logo: {
    height: 300,
    width: 300,
  }
});

export default Sobre;