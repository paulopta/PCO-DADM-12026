import { useState } from 'react';
import { Image, FlatList, StyleSheet, Text, View } from 'react-native';

/* Components */
import CabecalhoLista from '../components/CabecalhoLista'
import ItemSeparator from '../components/ItemSeparator'

/* Data */
import lutadores from '../data/Personagens.json'

const Personagens = () => {

    const [data, setData] = useState(lutadores);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
    {/*<Image source={{uri:item.imageUrl}} style={styles.image} /> */}
    <Image source={{uri:item.imageUrl}} style={styles.image} />
      <View style={{flex: 1, marginLeft: 16}}>
        <Text style={styles.PersonagemNome}>{item.nome}</Text>{' '} {/* Supondo que seu JSON tenha um campo 'nome' */}
        {/* Golpe 1 */}
        { item.golpe1Nome ?
        <>
        <Text style={styles.GolpeNome}>{item.golpe1Nome}</Text>
        <Text>{item.golpe1Comando}</Text>
        </>
        : 
        ""
        }

        {/* Golpe 2 */}
        { item.golpe2Nome ?
        <>
        <Text style={styles.GolpeNome}>{item.golpe2Nome}</Text>
        <Text>{item.golpe2Comando}</Text>
        </>
        : 
        ''
        }

        {/* Golpe 3 */}
        { item.golpe3Nome ?
        <>
        <Text style={styles.GolpeNome}>{item.golpe3Nome}</Text>
        <Text>{item.golpe3Comando}</Text>
        </>
        : 
        ''
        }

        {/* Golpe 3 */}
        { item.golpe3Nome ?
        <>
        <Text style={styles.GolpeNome}>{item.golpe3Nome}</Text>
        <Text>{item.golpe3Comando}</Text>
        </>
        : 
        ''
        }

        {/* Fatality */}
        { item.fatality != "" ?
        <>
        <Text style={styles.TituloFatality}>Fatality</Text>
        <Text>{item.fatality}</Text>
        </>
        : 
        ""
        }
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        ItemSeparatorComponent = <ItemSeparator />
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id} // Supondo que seu JSON tenha um campo 'id'
        ListHeaderComponent = <CabecalhoLista/>
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 20,
    borderColor: "black" 
  },
  item: {
   flexDirection: "row",
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 20
  },
  image: {
    width: 100,
    height: 100
  },
  PersonagemNome: {
    fontWeight: "bold",
    fontSize: 20
  },
  GolpeNome: {
    fontWeight: "bold",
    marginTop: 5
  },
  TituloFatality: {
    fontWeight: "bold",
    marginTop: 5,
    color: "red"
  },
});

export default Personagens;
