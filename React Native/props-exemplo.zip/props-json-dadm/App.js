import {View, StyleSheet} from 'react-native'

//components
import Titulo from './assets/components/titulo'
import Conteudo from './assets/components/conteudo'

//data
import Carros from './assets/data/carros.json'

const App = () => {

//variáveis
const data = [
  {marca:"Kia", modelo:"Cerato", ano:"2010", valor:"R$60.000,00"},
  {marca:"Ford", modelo:"Ka", ano:"2011", valor:"R$16.000,00"}
];

//<Conteudo props={data[0]} />

  return (
    <>
      <Titulo titulo="APP" versao="1.0" />
      <View style={style.container}>
      {
        Carros.map((carro) => 
          <Conteudo props={carro} />
        )
      }
      </View>
    </>
  );

}

const style = StyleSheet.create({
  container:{
    flex: 1,
    flexDirection: "row",
    gap: 2
  }
});

export default App;