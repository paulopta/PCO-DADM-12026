import {View, Text} from 'react-native'

//CSS
import Style from './titulo_style'


const Titulo = (props) => {

  return(
    <View>
      <Text style={Style.titulo}> {props.titulo + " - "+props.versao} </Text>
    </View>
  );

}

export default Titulo;