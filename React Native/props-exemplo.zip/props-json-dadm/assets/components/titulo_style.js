import {StyleSheet} from 'react-native'

export default style = StyleSheet.create({
  titulo: {
    fontSize: 20,
    backgroundColor: "green",
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
    padding: 20
  }
});