import {View, Text, StyleSheet} from 'react-native'

const Conteudo = ({props}) => {

  return(
    <View style={style.container}>
      <Text> <Text style={style.titulo}>Marca:</Text> {props.marca}  </Text>
      <Text> <Text style={style.titulo}>Modelo:</Text> {props.modelo}  </Text>
      <Text> <Text style={style.titulo}>Ano:</Text> {props.ano} </Text>
      <Text> <Text style={style.titulo}>Valor:</Text> {props.valor} </Text>
    </View>
  );

}

const style = StyleSheet.create({
  titulo:{
    fontWeight: "bold"
  },
  container:{
    backgroundColor: "#ffff",
    lineHeight: "1.5",
    borderColor: "black",
    borderStyle: "solid",
    borderWidth: 2,
    height:80
  }
});

export default Conteudo;