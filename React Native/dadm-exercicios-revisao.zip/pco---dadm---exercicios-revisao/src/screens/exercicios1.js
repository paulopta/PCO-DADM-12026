//importações gerais
import {useState} from 'react'
import {Text} from 'react-native'
import { TextInput } from 'react-native-paper';

//importações dos components
import Titulo from '../components/titulo'


const Exercicio1 = () => {

const [nome,setNome] = useState("");

return(
  <>
  <Titulo titulo="Exercício 1" />
  <TextInput
      label="Informe seu nome"
      value={nome}
      onChangeText={text => setNome(text)}
    />
   <Text> Seja bem vindo {nome}</Text>
  </>
);

}

export default Exercicio1;


