import { Appbar } from 'react-native-paper';

const Titulo = (props) => {

  return(
    <Appbar.Header>
      <Appbar.Content title={props.titulo} />
      <Appbar.Action icon="calculator" />
    </Appbar.Header>

  );

}

export default Titulo;