

//screens
import Exercicio1 from './src/screens/exercicios1'


const App = () => {

  return(

    <Exercicio1 />

  );

}

export default App;